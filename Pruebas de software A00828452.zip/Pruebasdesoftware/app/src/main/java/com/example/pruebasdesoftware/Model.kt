package com.example.pruebasdesoftware

class Model {
    var a : Double = 0.0
    var b : Double = 0.0

    fun sum() : Double{
        return a + b
    }

    fun sub() : Double{
        return a - b
    }

    fun mul() : Double{
        return a * b
    }

    fun div() : Double{
        return a / b
    }
}