package com.example.pruebasdesoftware

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    lateinit var number1: EditText
    lateinit var number2: EditText
    lateinit var buttonAdd: RadioButton
    lateinit var buttonSub: RadioButton
    lateinit var buttonMul: RadioButton
    lateinit var buttonDiv: RadioButton
    lateinit var calculate: Button
    lateinit var answer: TextView
    lateinit var warning: TextView

    lateinit var model: Model




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        number1 = findViewById(R.id.number1)
        number2 = findViewById(R.id.number2)
        buttonAdd = findViewById(R.id.buttonAdd)
        buttonSub = findViewById(R.id.buttonSub)
        buttonMul = findViewById(R.id.buttonMul)
        buttonDiv = findViewById(R.id.buttonDiv)
        calculate = findViewById(R.id.calculate)
        answer = findViewById(R.id.answer)
        warning = findViewById(R.id.warning)
        model = Model()

        calculate.setOnClickListener{

            warning.text = ""
            answer.text = ""

            if (number1.text.toString().isEmpty() || number2.text.toString().isEmpty()){
                warning.text = "Llena todos los parametros"
            }
            else{
                model.a = number1.text.toString().toDouble()
                model.b = number2.text.toString().toDouble()

                if(buttonAdd.isChecked){
                    answer.text = model.sum().toString()
                }
                else if(buttonSub.isChecked){
                    answer.text = model.sub().toString()
                }
                else if(buttonMul.isChecked){
                    answer.text = model.mul().toString()
                }
                else if(buttonDiv.isChecked){
                    if (model.b == 0.0){
                        answer.text = "Undefined"
                    }
                    else {
                        answer.text = model.div().toString()
                    }
                }
                else{
                    warning.text = "Llena todos los parametros"
                }
            }

        }

    }

}