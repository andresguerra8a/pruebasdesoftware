package com.example.pruebasdesoftware

import org.junit.Before
import org.junit.Test

class ModelTest{

    lateinit var model: Model

    @Before
    fun setUp(){
        model = Model()
    }

    @Test
    fun testSum() {
        model.a = 1.0
        model.b = 2.0
        assert(model.sum() == 3.0)
    }

    @Test
    fun testSub() {
        model.a = 1.0
        model.b = 2.0
        assert(model.sub() == -1.0)
    }

    @Test
    fun testMul() {
        model.a = 1.0
        model.b = 2.0
        assert(model.mul() == 2.0)
    }

    @Test
    fun testDiv() {
        model.a = 1.0
        model.b = 2.0
        assert(model.div() == 0.5)
    }
}